Aplikaci můžete zobrazit na https://gpointinteractive.com/generator, nebo spustit pomocí npm run dev

Pro použití aplikace se prosím zaregistrujte a následně přihlašte.